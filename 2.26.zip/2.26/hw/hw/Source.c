#include<stdio.h>
#include<stdlib.h>

int main(void)
{
	int n1, n2;
	n1 = num here;
	n2 = num here;
	while (n1 <= n2)
	{
		if (n1 % num here == 0)
			printf("%d ", n1);
		n1 = n1 + 1;
	}
}