#include <stdio.h>
#include <stdlib.h>

int main()
{
	float principle, rate, time, CI;

	printf("principle here(amount): ");
	scanf_s("%f", &principle);

	printf("time here: ");
	scanf_s("%f", &time);

	printf("rate here: ");
	scanf_s("%f", &rate);

	CI = principle * (pow((1 + rate / 100), time));

	printf("Compound Interest = %f", CI);

	return 0;
}