#include <stdio.h>
#include <stdlib.h>

int main() {
	float sales, commission, earnings;

	while (true) {
		printf("sales in dollars here( -1 to end ): ");
		scanf_s("%f", &sales);

		if (sales == -1) {
			return 0;
		}

		commission = sales / 100 * 9;
		earnings = commission + 200;

		printf("Salary is %.2f\n", earnings);
	}

	return 0;
}