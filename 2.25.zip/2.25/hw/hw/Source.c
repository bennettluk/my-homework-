#include<stdio.h>
#include<stdlib.h>

int main(void)
{
	printf("LLLLLL\n");
	printf("L\n");
	printf("L\n");
	printf(" \n");
	printf(" UUUUU\n");
	printf("U\n");
	printf(" UUUUU\n");
	printf(" \n");
	printf("KKKKKK\n");
	printf("  K\n");
	printf("KK  KK\n");
	system("pause");
	return 0;
}