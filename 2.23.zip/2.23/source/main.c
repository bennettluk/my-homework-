#include <stdio.h>
#include <stdlib.h>

int main(void)
{
	int n1, n2, n3, smallest, largest;
	
	scanf_s("%d", &n1);
	scanf_s("%d", &n2);
	scanf_s("%d", &n3);

	largest = n1;

	if (largest < n2)
	{
		largest = n2;
	}

	if (largest < n3)
	{
		largest = n3;
	}

	smallest = n1;

	if (smallest > n2)
	{
		smallest = n2;
	}

	if (smallest > n3)
	{
		smallest = n3;
	}

	printf("in(%d.%d.%d), the largest integer is %d\n", n1, n2, n3, largest);
	printf("in(%d.%d.%d), the smallest integer is %d\n", n1, n2, n3, smallest);

	system("pause");
	return 0;
}
