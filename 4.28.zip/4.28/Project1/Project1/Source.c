#include <stdio.h>

int main()
{
	int payrate;
	int hours;
	printf("standard hourly pay rate here \n");
	scanf_s("%d", &payrate);
	printf("work hour in a week here\n");
	scanf_s("%d", &hours);

	int weeklypay = hours * payrate;
	int overtimehours = hours - 40;
	int overtimepay = weeklypay * 1.5;
	int overtimesalary = weeklypay + (overtimehours * overtimepay);


	if (hours <= 40)
		printf("weekly pay is %d . \n", weeklypay);

	else
		printf("weekly pay is %d . \n", overtimesalary);

	return 0;
}