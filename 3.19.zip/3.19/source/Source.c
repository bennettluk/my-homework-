#include <stdio.h>
#include <stdlib.h>

int main() {
	int days;
	float principal, rate, interest;

	while (true) {
		printf("the loan principal here(-1 to end): ");
		scanf_s("%f", &principal);
		if (principal == -1) {
			return 0;
		}
		printf("interest rate here: ");
		scanf_s("%f", &rate);
		printf("term of the loan in days here: ");
		scanf_s("%d", &days);

		interest = principal * rate * days / 365;
		printf("interest charge is $%.2f\n", interest);
	}

	return 0;
}